create function st_inversetransformpipeline(geom geometry, pipeline text, to_srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public.postgis_transform_pipeline_geometry($1, $2, FALSE, $3)$$;

comment on function st_inversetransformpipeline(geometry, text, integer) is 'args: geom, pipeline, to_srid - Return a new geometry with coordinates transformed to a different spatial reference system using the inverse of a defined coordinate transformation pipeline.';

alter function st_inversetransformpipeline(geometry, text, integer) owner to livio;

