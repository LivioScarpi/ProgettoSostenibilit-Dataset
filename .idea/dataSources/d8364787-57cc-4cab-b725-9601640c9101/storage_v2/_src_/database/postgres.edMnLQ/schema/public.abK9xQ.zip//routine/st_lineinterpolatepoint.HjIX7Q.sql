create function st_lineinterpolatepoint(text, double precision) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_LineInterpolatePoint($1::public.geometry, $2);  $$;

alter function st_lineinterpolatepoint(text, double precision) owner to livio;

